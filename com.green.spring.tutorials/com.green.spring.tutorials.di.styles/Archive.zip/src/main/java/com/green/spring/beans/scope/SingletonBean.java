package com.green.spring.beans.scope;

import org.springframework.stereotype.Component;

@Component
public class SingletonBean {

}
