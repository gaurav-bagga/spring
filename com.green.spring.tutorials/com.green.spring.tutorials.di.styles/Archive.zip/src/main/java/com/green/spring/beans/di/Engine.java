package com.green.spring.beans.di;

public interface Engine {

	public void drive();
}
