package com.green.spring.beans.di.autowire;

public interface Instrument {

	public void play();
}
